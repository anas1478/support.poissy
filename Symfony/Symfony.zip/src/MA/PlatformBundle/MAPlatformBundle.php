<?php

namespace MA\PlatformBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class MAPlatformBundle extends Bundle
{
}
