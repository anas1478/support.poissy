<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_3f88c5fe41989a338bc6eea98eaf2fe2e1d8aa0c4e2f379e6601261b4a52d4bc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d181017283c7314cc69dadd4ea10686b5fe4ff3cb2d857d69250e7014448f5e2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d181017283c7314cc69dadd4ea10686b5fe4ff3cb2d857d69250e7014448f5e2->enter($__internal_d181017283c7314cc69dadd4ea10686b5fe4ff3cb2d857d69250e7014448f5e2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        $__internal_b8c27f66c078adb11d390e08700e1a3539a0fdee7fb8407093d2ecac5e16d173 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b8c27f66c078adb11d390e08700e1a3539a0fdee7fb8407093d2ecac5e16d173->enter($__internal_b8c27f66c078adb11d390e08700e1a3539a0fdee7fb8407093d2ecac5e16d173_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_d181017283c7314cc69dadd4ea10686b5fe4ff3cb2d857d69250e7014448f5e2->leave($__internal_d181017283c7314cc69dadd4ea10686b5fe4ff3cb2d857d69250e7014448f5e2_prof);

        
        $__internal_b8c27f66c078adb11d390e08700e1a3539a0fdee7fb8407093d2ecac5e16d173->leave($__internal_b8c27f66c078adb11d390e08700e1a3539a0fdee7fb8407093d2ecac5e16d173_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "@Framework/Form/button_label.html.php", "C:\\xampp\\htdocs\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\button_label.html.php");
    }
}
