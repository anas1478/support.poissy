<footer>
            <div class="container">
                <div class="row">
                    <div class="col-sm-6">
                        <p class="copyright">© Copyright  <?=  date('Y') ?> <a href="#" target="_blank"> Anas YOUSFI </a></p>
                    </div>
                </div>
            </div>
        </footer>

        <!-- Necessery scripts -->
        <script src="assets/js/jquery-2.1.3.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="https://maps.googleapis.com/maps/api/js?v=3.exp"></script>
        <script src="assets/js/jquery.actual.min.js"></script>
        <script src="assets/js/smooth-scroll.js"></script>
        <script src="assets/js/owl.carousel.js"></script>
        <script src="assets/js/script.js"></script>
        <script>

        // $(function () {
        //     var api = "https://api.deezer.com/oembed?url=https://www.deezer.com/fr/playlist/4412309342";
        //         $.ajax(
        //             url: api, 
        //             format: "jsonp"
        //         ).done(function (data)) {
        //                 console.log(data, data.html);
        //                 $("#player").html(JSON.stringify(data));
        //                 // or work with the data here, already in object format// headers: {'Content-Type' : 'application/json', 'Access-Control-Allow-Origin' : 'https://api.deezer.com/oembed?url=https://www.deezer.com/fr/playlist/4412309342'},
        //             });
                   
        //     });


        </script>
    </body>
</html>
