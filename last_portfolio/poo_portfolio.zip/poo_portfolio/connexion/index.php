
<?php
header("location: ../front");