# KO des mots

Cette application est utilisée dans le cadre du spectacle KO des mots produit par AD2Production

[Voir le teaser](https://www.youtube.com/watch?v=_Y2dDjVUGV4)

# Backlog

https://trello.com/b/TlPMWW8P/ko-des-mots
