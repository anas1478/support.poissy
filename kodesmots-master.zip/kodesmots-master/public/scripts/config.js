﻿//// CONFIGURATION

// Durée par défaut des rounds en secondes, default 300 = 5 minutes
var maxTime 		= 300; 


// Taille du texte ; orginialement 23
var masterFont		= 23;

// Texte panneau de fin ">" pour nouvelle ligne
var leTexteDeFin	= 'Le K.O. des Mots>Une création AD2 productions>ad.ad.prod@gmail.com';
