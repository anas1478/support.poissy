<?php
require_once 'autoload.php';



$controller = new Controller\Controller; 


$controller->handlerRequest();