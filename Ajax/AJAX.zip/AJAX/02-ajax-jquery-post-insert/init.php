<?php
$bdd = new PDO('mysql:host=localhost;dbname=entreprise', 'root', '');
