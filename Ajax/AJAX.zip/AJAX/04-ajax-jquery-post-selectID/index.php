<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
    <script
    src="https://code.jquery.com/jquery-3.3.1.min.js"
    integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
    crossorigin="anonymous"></script>
    <script src="ajax3.js"></script>
    <title>AJAX DELETE JQUERY</title>
</head>
<body>
    <div class="container">

        <h1 class="display-4 text-center">AJAX DELETE JQUERY</h1><hr>

        <!-- 
            Exo :
            1 - connexion, BDD dans init.php 
            
            2 - Réaliser le selecteur en PHP de tout les employés dans index.php
            3 - dans le fichier ajax4.php, réaliser la requête PHP permettant de selectionner un employé dans la BDD
            4 - Réalsier le traitement permettant d'afficher les données d'un employé dans le fichier ajax4.php
            5 - encoder en JSON
            6 - Réaliser le traitement JS permettant d'envoyer les requetes AJAX dans le fichier ajax4.js
        -->
        
    </div>
</body>
</html>